
#ifndef Decoder_H 			
#define	Decoder_H




void  decoder (void)
#endif	