 //由于Display,c 里面要用到 51单片机寄存器
/*--------------- 必要的头文件 ----------------*/
#include "reg52.h"

#ifndef sbit_H 			//理解为	if not define led.h
#define sbit_H 			//如果没有定义 led.h ,这里就定义一个 led.h


#endif	// 定义结束