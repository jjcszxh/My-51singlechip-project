#ifndef Delay_H 			//理解为	if not define led.h
#define Delay_H 			//如果没有定义 led.h ,这里就定义一个 led.h
 
#define u16	unsigned int
void Delay(u16 t);
 
#endif	// 定义结束